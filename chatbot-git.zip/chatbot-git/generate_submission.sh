#!/usr/bin/env bash
rm -f submission.zip
zip -r submission.zip chatbot.py PorterStemmer.py rubric.txt ./deps
